<!-- src/views/Inicio.vue -->
<template>
    <ion-content>
      <CitaAccionesCrud></CitaAccionesCrud>
    </ion-content>
  </template>
  
  <script>
  import CitaAccionesCrud from '../components/CitaAccionesCrud.vue';
  export default {
    name: 'Inicio',
    components: {
      CitaAccionesCrud,
    },
  };
  </script>
  
  <style scoped>
  /* Estilos específicos para la vista */
  </style>
  