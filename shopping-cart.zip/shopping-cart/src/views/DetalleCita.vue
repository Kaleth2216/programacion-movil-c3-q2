<!-- src/views/DetalleCita.vue -->
<template>
    <ion-content>
      <CitaTarjetaDetalle></CitaTarjetaDetalle>
    </ion-content>
  </template>
  
  <script>
  import CitaTarjetaDetalle from '../components/CitaTarjetaDetalle.vue';
  
  export default {
    name: 'DetalleCita',
    components: {
      CitaTarjetaDetalle,
    },
  };
  </script>
  
  <style scoped>
  /* Estilos específicos para la vista */
  </style>
  