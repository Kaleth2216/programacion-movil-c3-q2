<!-- src/views/NuevaCita.vue -->
<template>
    <ion-content>
      <CitaFormulario></CitaFormulario>
    </ion-content>
  </template>
  
  <script>
  import CitaFormulario from '../components/CitaFormulario.vue';
  
  export default {
    name: 'NuevaCita',
    components: {
      CitaFormulario,
    },
  };
  </script>
  
  <style scoped>
  /* Estilos específicos para la vista */
  </style>
  