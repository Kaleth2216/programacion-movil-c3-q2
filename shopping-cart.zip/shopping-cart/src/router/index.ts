// src/router/index.js
import { createRouter, createWebHistory } from 'vue-router';
import Inicio from '../views/Inicio.vue';
import NuevaCita from '../views/NuevaCita.vue';
import DetalleCita from '../views/DetalleCita.vue';

const routes = [
  { path: '/', name: 'Inicio', component: Inicio },
  { path: '/nueva-cita', name: 'NuevaCita', component: NuevaCita }, // Path en kebab-case, nombre de archivo y componente en PascalCase
  { path: '/detalle-cita', name: 'DetalleCita', component: DetalleCita },
];
const router = createRouter({
  history: createWebHistory(),
  routes,
});

export default router;
