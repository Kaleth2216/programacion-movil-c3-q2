<!-- src/App.vue -->
<template>
  <ion-app>
    <Navegacion />
    <router-view></router-view>
    <ion-button @click="$router.push('/nueva-cita')">Ir a Nueva Cita (Prueba)</ion-button>
  </ion-app>
</template>

<script>
import Navegacion from './components/Navegacion.vue';

export default {
  name: 'App',
  components: {
    Navegacion,
  },
  watch: {
    $route(to, from) {
      console.log(`Cambio de ruta: de ${from.path} a ${to.path}`);
    }
  }
};
</script>

<style>
/* Estilos globales de la aplicación */
</style>
