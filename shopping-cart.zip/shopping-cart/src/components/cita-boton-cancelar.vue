<!-- src/components/CitaBotonCancelar.vue -->
<template>
    <ion-button color="danger" expand="block">Cancelar Cita</ion-button>
  </template>
  
  <script>
  export default {
    name: 'CitaBotonCancelar',
  };
  </script>
  
  <style scoped>
  /* Estilos específicos para el componente */
  </style>
  