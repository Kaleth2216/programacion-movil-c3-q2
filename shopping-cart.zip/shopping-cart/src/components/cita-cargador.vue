<!-- src/components/CitaCargador.vue -->
<template>
    <ion-spinner name="crescent"></ion-spinner>
  </template>
  
  <script>
  export default {
    name: 'CitaCargador',
  };
  </script>
  
  <style scoped>
  /* Estilos específicos para el componente */
  </style>
  