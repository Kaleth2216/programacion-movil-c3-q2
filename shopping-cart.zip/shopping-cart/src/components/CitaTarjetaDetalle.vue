<!-- src/components/CitaTarjetaDetalle.vue -->
<template>
    <div>
      <cita-avatar :image-url="avatarUrl"></cita-avatar>
      <cita-tarjeta-info title="Cita Médica" content="Detalles de la cita..."></cita-tarjeta-info>
      <cita-acciones-crud></cita-acciones-crud>
    </div>
  </template>
  
  <script>
  import CitaAvatar from './cita-avatar.vue';
  import CitaTarjetaInfo from './cita-tarjeta-info.vue';
  import CitaAccionesCrud from './CitaAccionesCrud.vue';
  
  export default {
    name: 'CitaTarjetaDetalle',
    components: {
      CitaAvatar,
      CitaTarjetaInfo,
      CitaAccionesCrud,
    },
    data() {
      return {
        avatarUrl: 'assets/avatar.png', // Puedes cambiar esta URL según tu necesidad
      };
    },
  };
  </script>
  
  <style scoped>
  /* Estilos específicos para el componente */
  </style>
  