<template>
  <ion-header>
    <ion-toolbar>
      <ion-title>Citas Médicas</ion-title>
      <ion-buttons slot="end">
        <ion-button @click="navigateTo('/')">Inicio</ion-button>
        <ion-button @click="navigateTo('/nueva-cita')">Nueva Cita</ion-button>
        <ion-button @click="navigateTo('/detalle-cita')">Detalle Cita</ion-button>
      </ion-buttons>
    </ion-toolbar>
  </ion-header>
</template>

<script>
export default {
  name: 'Navegacion',
  methods: {
  navigateTo(route) {
    console.log(`Navegando a: ${route}`);
    console.log(this.$router); // Asegúrate de que $router esté definido
    this.$router.push(route);
  },
},
}

</script>
