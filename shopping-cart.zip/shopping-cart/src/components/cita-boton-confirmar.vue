<!-- src/components/CitaBotonConfirmar.vue -->
<template>
    <ion-button color="primary" expand="block">Confirmar Cita</ion-button>
  </template>
  
  <script>
  export default {
    name: 'CitaBotonConfirmar',
  };
  </script>
  
  <style scoped>
  /* Estilos específicos para el componente */
  </style>
  