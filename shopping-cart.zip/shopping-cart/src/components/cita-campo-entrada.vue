<!-- src/components/CitaCampoEntrada.vue -->
<template>
    <ion-item>
      <ion-label position="floating">{{ label }}</ion-label>
      <ion-input v-model="value" type="text"></ion-input>
    </ion-item>
  </template>
  
  <script>
  export default {
    name: 'CitaCampoEntrada',
    props: {
      label: {
        type: String,
        default: 'Ingrese texto',
      },
    },
    data() {
      return {
        value: '',
      };
    },
  };
  </script>
  
  <style scoped>
  /* Estilos específicos para el componente */
  </style>