<!-- src/components/CitaAvatar.vue -->
<template>
    <ion-avatar>
      <img :src="imageUrl" alt="Paciente">
    </ion-avatar>
  </template>
  
  <script>
  export default {
    name: 'CitaAvatar',
    props: {
      imageUrl: {
        type: String,
        default: 'assets/avatar.png',
      },
    },
  };
  </script>
  
  <style scoped>
  /* Estilos específicos para el componente */
  </style>
  