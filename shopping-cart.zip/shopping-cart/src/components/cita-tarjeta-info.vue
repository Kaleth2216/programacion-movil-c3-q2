<!-- src/components/CitaTarjetaInfo.vue -->
<template>
    <ion-card>
      <ion-card-header>
        <ion-card-title>{{ title }}</ion-card-title>
      </ion-card-header>
      <ion-card-content>
        {{ content }}
      </ion-card-content>
    </ion-card>
  </template>
  
  <script>
  export default {
    name: 'CitaTarjetaInfo',
    props: {
      title: {
        type: String,
        default: 'Detalles de la Cita',
      },
      content: {
        type: String,
        default: 'Información detallada de la cita',
      },
    },
  };
  </script>
  
  <style scoped>
  /* Estilos específicos para el componente */
  </style>
  