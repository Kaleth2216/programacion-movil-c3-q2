<!-- src/components/CitaSelectorHora.vue -->
<template>
    <ion-item>
      <ion-label>Hora de Cita</ion-label>
      <ion-datetime display-format="HH:mm" picker-format="HH:mm" v-model="selectedTime"></ion-datetime>
    </ion-item>
  </template>
  
  <script>
  export default {
    name: 'CitaSelectorHora',
    data() {
      return {
        selectedTime: '',
      };
    },
  };
  </script>
  
  <style scoped>
  /* Estilos específicos para el componente */
  </style>
  