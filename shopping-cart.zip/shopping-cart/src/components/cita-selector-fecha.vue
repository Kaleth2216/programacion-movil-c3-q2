<!-- src/components/CitaSelectorFecha.vue -->
<template>
    <ion-item>
      <ion-label>Fecha de Cita</ion-label>
      <ion-datetime display-format="DD-MM-YYYY" v-model="selectedDate"></ion-datetime>
    </ion-item>
  </template>
  
  <script>
  export default {
    name: 'CitaSelectorFecha',
    data() {
      return {
        selectedDate: '',
      };
    },
  };
  </script>
  
  <style scoped>
  /* Estilos específicos para el componente */
  </style>
  