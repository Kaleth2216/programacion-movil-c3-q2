<!-- src/components/CitaNotificacion.vue -->
<template>
    <ion-toast :is-open="isOpen" :message="message" duration="2000"></ion-toast>
  </template>
  
  <script>
  export default {
    name: 'CitaNotificacion',
    props: {
      message: {
        type: String,
        default: 'Notificación de la cita',
      },
    },
    data() {
      return {
        isOpen: true,
      };
    },
  };
  </script>
  
  <style scoped>
  /* Estilos específicos para el componente */
  </style>
  