<!-- src/components/CitaCheckbox.vue -->
<template>
    <ion-item>
      <ion-label>{{ label }}</ion-label>
      <ion-checkbox slot="start" v-model="checked"></ion-checkbox>
    </ion-item>
  </template>
  
  <script>
  export default {
    name: 'CitaCheckbox',
    props: {
      label: {
        type: String,
        default: 'Aceptar términos',
      },
    },
    data() {
      return {
        checked: false,
      };
    },
  };
  </script>
  
  <style scoped>
  /* Estilos específicos para el componente */
  </style>
  