<!-- src/components/CitaFormulario.vue -->
<template>
    <div>
      <cita-campo-entrada label="Nombre del Paciente"></cita-campo-entrada>
      <cita-selector-fecha></cita-selector-fecha>
      <cita-selector-hora></cita-selector-hora>
      <cita-boton-confirmar></cita-boton-confirmar>
    </div>
  </template>
  
  <script>
  import CitaCampoEntrada from './cita-campo-entrada.vue';
  import CitaSelectorFecha from './cita-selector-fecha.vue';
  import CitaSelectorHora from './cita-selector-hora.vue';
  import CitaBotonConfirmar from './cita-boton-confirmar.vue';
  
  export default {
    name: 'CitaFormulario',
    components: {
      CitaCampoEntrada,
      CitaSelectorFecha,
      CitaSelectorHora,
      CitaBotonConfirmar,
    },
  };
  </script>
  
  <style scoped>
  /* Estilos específicos para el componente */
  </style>
  