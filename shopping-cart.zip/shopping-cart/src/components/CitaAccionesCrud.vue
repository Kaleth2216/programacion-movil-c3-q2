<!-- src/components/CitaAccionesCrud.vue -->
<template>
    <div>
      <ion-button color="primary">Crear</ion-button>
      <ion-button color="secondary">Leer</ion-button>
      <ion-button color="tertiary">Actualizar</ion-button>
      <ion-button color="danger">Eliminar</ion-button>
    </div>
  </template>
  
  <script>
  export default {
    name: 'CitaAccionesCrud',
  };
  </script>
  
  <style scoped>
  /* Estilos específicos para el componente */
  </style>
  